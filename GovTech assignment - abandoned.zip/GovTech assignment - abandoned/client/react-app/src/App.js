import React, { useState, useEffect } from 'react';
import axios from 'axios';
import io from 'socket.io-client';

const API_BASE_URL = 'http://localhost:4000/api'; // Replace with your API's base URL

function App() {
  const [username, setUsername] = useState('');
  const [playerId, setPlayerId] = useState('');
  const [gameId, setGameId] = useState('');
  const [xPlayer, setXPlayer] = useState('');
  const [yPlayer, setYPlayer] = useState('');
  const [turnPlayer, setTurnPlayer] = useState('');
  const [board, setBoard] = useState(Array(9).fill(null));
  const [winner, setWinner] = useState(null);
  const [message, setMessage] = useState('');
  const [socket, setSocket] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Connect to WebSocket server
    const newSocket = io(API_BASE_URL);
    setSocket(newSocket);

    return () => {
      newSocket.disconnect();
    };
  }, []);

  const handleUsernameSubmit = () => {
    // If username is empty, reject it
    if (!username) {
      alert('Please enter a valid username');
      return;
    }

    // Register user and join queue
    axios
      .post(`${API_BASE_URL}/queue`, { playerName: username })
      .then((response) => {
        const { playerId } = response.data;
        setPlayerId(playerId);
        setIsLoading(true); // Show loading screen
      })
      .catch((error) => console.error('Registration error:', error));
  };

  useEffect(() => {
    if (!socket) return;

    socket.on('matchFound', (data) => {
      const { gameId, xPlayer, yPlayer, turnPlayer } = data;
      setGameId(gameId);
      setXPlayer(xPlayer);
      setYPlayer(yPlayer);
      setTurnPlayer(turnPlayer);
      setIsLoading(false); // Transition to the game page
    });

    socket.on('gameUpdate', (data) => {
      setBoard(data.board);
      setTurnPlayer(data.turnPlayer);
      setWinner(data.winner);
      setMessage(data.message);
    });
  }, [socket]);

  const handleCellClick = (index) => {
    if (!board[index] && playerId === turnPlayer) {
      socket.emit('play', { gameId, playerId, selectedCell: index + 1 });
    }
  };

  return (
    <div className="App">
      <h1>Tic Tac Toe</h1>
      {isLoading ? (
        <div className="loading-screen">
          <p>Please wait for a player</p>
          <div className="spinner"></div>
        </div>
      ) : !playerId ? (
        <div>
          <input
            type="text"
            placeholder="Enter your username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <button onClick={handleUsernameSubmit}>Submit</button>
        </div>
      ) : (
        <div>
          <div className="game-board">
            {board.map((cell, index) => (
              <div
                key={index}
                className={`cell ${cell}`}
                onClick={() => handleCellClick(index)}
              >
                {cell}
              </div>
            ))}
          </div>
          <div className="game-info">
            <p>X Player: {xPlayer}</p>
            <p>Y Player: {yPlayer}</p>
            <p>Turn Player: {turnPlayer}</p>
            <p>{message}</p>
            {winner && <p>Winner: {winner}</p>}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
