const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const mysql = require('mysql2');
const cors = require('cors');
const port = 4000;

const app = express();
app.use(cors());
app.use(express.json());
const server = http.createServer(app);
const io = socketIo(server);

const db = mysql.createConnection({
  host: '127.0.0.1',
  user: 'root',
  password: 'cdev',
  database: 'mydb',
});

// Establish database connection
db.connect(err => {
  if (err) {
    console.error('Failed to connect to the database:', err);
    process.exit(1); // Exit the application with an error code
  }
  console.log('Connected to the database');
});

// Register WebSocket events
io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });

  // Add a new event listener for "matchFound" when a player is matched
  socket.on('matchFound', ({ gameId, xPlayer, yPlayer, turnPlayer }) => {
    // You can send game details to the specific socket here or handle it as needed
    // Example: io.to(socket.id).emit('matchFound', { gameId, xPlayer, yPlayer, turnPlayer });
  });

  socket.on('play', ({ gameId, playerId, selectedCell }) => {
    // ... (Previous play logic)
  });
});

function gameToBoard(game) {
  const board = [];
  for (let i = 1; i <= 9; i++) {
    board.push(game[`cell${i}`]);
  }
  return board;
}

// QUEUING FOR A GAME
app.post('/api/queue', (req, res) => {
  const { playerName } = req.body;
  db.query('INSERT INTO players SET ? , status = "q"', { playerName }, (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Failed to add player to queue' });
    } else {
      const playerId = result.insertId; // Get the playerId from the result
      res.status(201).json({ message: 'Player added to queue successfully', playerId });
    }
  });
});

// MATCHMAKING
app.get('/api/matchmaking', (req, res) => {
  const { playerId } = req.body;
  db.query('SELECT * FROM players WHERE status = "q" AND playerId != ?', [playerId], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Failed to find a match' });
    } else {
      const opponent = result[0];
      if (opponent) {
        // Found a match
        const roles = ['X', 'Y'];
        const randomIndex = Math.floor(Math.random() * roles.length);
        const randomRole = roles[randomIndex];

        const gameId = `${Date.now()}_${playerId}_${opponent.playerId}`;

        const newGame = {
          gameId,
          X: randomRole === 'X' ? playerId : opponent.playerId,
          Y: randomRole === 'Y' ? playerId : opponent.playerId,
          turn: randomRole === 'X' ? playerId : opponent.playerId,
        };

        // Create the game
        db.query('INSERT INTO games SET ?', newGame, (err, result) => {
          if (err) {
            console.error(err);
            res.status(500).json({ error: 'Failed to create a new game' });
            return;
          } else {
            // Determine who is X and who is Y
            const xPlayer = newGame.X;
            const yPlayer = newGame.Y;

            // Determine whose turn it is
            const turnPlayer = newGame.turn;

            // Emit "matchFound" event to the players
            io.to(playerId).emit('matchFound', {
              gameId,
              xPlayer,
              yPlayer,
              turnPlayer,
            });

            io.to(opponent.playerId).emit('matchFound', {
              gameId,
              xPlayer,
              yPlayer,
              turnPlayer,
            });

            // Update players' status to "p"
            db.query('UPDATE players SET status = "p" WHERE playerId IN (?, ?)', [playerId, opponent.playerId], (err, result) => {
              if (err) {
                console.error(err);
                res.status(500).json({ error: 'Failed to update players' });
                return;
              }
            });
          }
        });
      } else {
        // No match found
        res.status(404).json({ message: 'No match found' });
      }
    }
  });
});

// PLAYING
const winningCombos = [
  [1, 2, 3], [4, 5, 6], [7, 8, 9],
  [1, 4, 7], [2, 5, 8], [3, 6, 9],
  [1, 5, 9], [3, 5, 7]
];

function checkWinningCombo(game, player, selectedCell) {
  const updatedGame = { ...game };
  updatedGame[`cell${selectedCell}`] = player; // Update the game state with the current move

  const playerCells = [];
  for (let i = 1; i <= 9; i++) {
    playerCells.push(updatedGame[`cell${i}`]);
  }

  for (const combo of winningCombos) {
    const hasCombo = combo.every(cellIndex => playerCells[cellIndex - 1] === player);
    if (hasCombo) {
      return combo; // Return the winning combination
    }
  }
  console.log(playerCells);
  return false; // No winning combination found
}

app.get('/api/game/:gameId', (req, res) => {
  const { gameId } = req.params;
  const { playerId, selectedCell } = req.body;

  db.query('SELECT * FROM games WHERE gameId = ?', [gameId], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Failed to get game' });
    } else {
      const game = result[0];
      if (!game) {
        res.status(404).json({ error: 'Game not found' });
        return;
      }
      if (game.winner) {
        res.status(400).json({ error: 'Game has ended' });
        return;
      }
      if (game.turn === playerId) {
        const player = game.X === playerId ? 'X' : 'Y';

        if (game[`cell${selectedCell}`] === null) {
          const updateQuery = `UPDATE games SET cell${selectedCell} = ? WHERE gameId = ?`;
          db.query(updateQuery, [player, gameId], (err, result) => {
            if (err) {
              console.error(err);
              res.status(500).json({ error: 'Failed to update cell' });
            } else {
              const hasWinningCombo = checkWinningCombo(game, player, selectedCell);

              if (hasWinningCombo) {
                const winnerUpdateQuery = 'UPDATE games SET winner = ? WHERE gameId = ?';
                db.query(winnerUpdateQuery, [player, gameId], (err, result) => {
                  if (err) {
                    console.error(err);
                    res.status(500).json({ error: 'Failed to update winner' });
                  } else {
                    // Fetch the updated game state from the database
                    db.query('SELECT * FROM games WHERE gameId = ?', [gameId], (err, updatedResult) => {
                      if (err) {
                        console.error(err);
                        res.status(500).json({ error: 'Failed to fetch updated game state' });
                      } else {
                        const updatedGame = updatedResult[0];
                        res.status(200).json({
                          message: `${player} wins with the combination of ${hasWinningCombo}!`,
                          winner: player,
                          gameState: updatedGame // Include the updated game state in the response
                        });
                      }
                    });
                  }
                });

              } else {
                const allCellsOpen = Object.keys(updatedGame)
                  .filter(key => key.startsWith('cell'))
                  .every(key => updatedGame[key] !== null);

                if (allCellsOpen) {
                  const tieUpdateQuery = 'UPDATE games SET winner = ? WHERE gameId = ?';
                  db.query(tieUpdateQuery, ['T', gameId], (err, result) => {
                    if (err) {
                      console.error(err);
                      res.status(500).json({ error: 'Failed to update winner' });
                    } else {
                      res.status(200).json({ message: "It's a tie!", winner: 'T' });
                    }
                  });
                } else {
                  const newTurn = game.turn === game.X ? game.Y : game.X;
                  const turnUpdateQuery = 'UPDATE games SET turn = ? WHERE gameId = ?';
                  db.query(turnUpdateQuery, [newTurn, gameId], (err, result) => {
                    if (err) {
                      console.error(err);
                      res.status(500).json({ error: 'Failed to update turn' });
                    } else {
                      res.status(200).json({ message: `${player} opened cell ${selectedCell}`, newTurn });
                    }
                  });
                }
              }
            }
          });
        } else {
          res.status(400).json({ error: 'Cell is unavailable' });
        }
      } else {
        res.status(400).json({ error: "Not your turn" });
      }
    }
  });
});

// Start the server
server.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
